package com.example.jingbin.designpattern.factory.jdgc;

/**
 * Created by jingbin on 2016/10/22.
 */

public class ZTianRoujiaMo extends RoujiaMo {

    public ZTianRoujiaMo() {
        this.name = "甜味肉夹馍";
    }
}
