package com.example.jingbin.designpattern.command;

/**
 * Created by jingbin on 2016/10/31.
 */

public interface Command {

    public void execute();
}
