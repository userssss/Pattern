package com.example.jingbin.designpattern.strategy.better;

/**
 * Created by jingbin on 2016/10/30.
 */

public class RoleA extends Role {

    public  RoleA(String name){
        this.name = name;
    }
}
