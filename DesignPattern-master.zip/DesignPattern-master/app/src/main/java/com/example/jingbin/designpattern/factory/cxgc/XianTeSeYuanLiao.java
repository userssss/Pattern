package com.example.jingbin.designpattern.factory.cxgc;

/**
 * Created by jingbin on 2016/10/26.
 */

public class XianTeSeYuanLiao extends YuanLiao {

    public String yuanliao = "西安特色原料";
}
