package com.example.jingbin.designpattern.factory.cxgc;

/**
 * Created by jingbin on 2016/10/26.
 */

public class ChangShaTeSeYuanLiao extends YuanLiao {

    public String yuanliao = "长沙特色原料";
}
