package com.example.jingbin.designpattern.decorator.gem;

import com.example.jingbin.designpattern.decorator.IEquip;

/**
 * Created by jingbin on 2016/11/1.
 * 装饰品的接口
 */

public interface IEuipDecotator extends IEquip {

}
