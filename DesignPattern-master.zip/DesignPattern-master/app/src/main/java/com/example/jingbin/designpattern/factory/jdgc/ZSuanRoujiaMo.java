package com.example.jingbin.designpattern.factory.jdgc;

/**
 * Created by jingbin on 2016/10/22.
 */

public class ZSuanRoujiaMo extends RoujiaMo {

    public ZSuanRoujiaMo() {
        this.name = "酸味肉夹馍";
    }
}
